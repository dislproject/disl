#script to remove images from image file.

cd ../../../../scratch/py00024/disl/Animate/images/
rm *.bmp
