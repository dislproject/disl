#include "externVar.h"

Grid::Grid()
{
    //Initialise all values to zero.
    x=y=0;
    stress_x=stress_y=stress_net=0;
    strain_x=strain_y=strain_net=0;
    val=0;
    colour=0;

}
