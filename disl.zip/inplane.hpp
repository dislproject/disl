#ifndef INPLANE_HPP
#define INPLANE_HPP

class Inplane
{
public:
    Inplane();
    int run_inplane(int option);
};

#endif // INPLANE_HPP
